import React from 'react'
function Collaboration(){

    
return(
    <div>ffgfgfggf</div>
);
}

export default Collaboration;