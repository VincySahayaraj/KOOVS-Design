import React, { useRef, useState } from "react";
import { Carousel, Button, Row, Col, Container } from "react-bootstrap";
import "./homebanner.css";
import firstimg from "../../assets/images/homepage.png";
import secondimg from "../../assets/images/IMG_4249 (1).png";
import thirdimg from '../../assets/images/IMG_4250 (1).png'
import rightarrow from '../../assets/images/RightIcon.png';
import leftarrow from '../../assets/images/LeftIcon.png'
import Slider from 'react-slick'
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";


//Custom arrow for Next
function SampleNextArrow(props) {
    const { className, style, onClick } = props;
    return (
        <div
            className={className}
            style={{ ...style, display: "block", background: "#FFFFFF" }}
            onClick={onClick}
        ><img src={rightarrow} className='rightarrowicon'></img></div>
    );
}

//Custom arrow for Previous
function SamplePrevArrow(props) {
    const { className, style, onClick } = props;
    return (
        <div
            className={className}
            style={{ ...style, display: "block", background: "#FFFFFF" }}
            onClick={onClick}
        ><img src={leftarrow} className="leftarrowicon"></img></div>
    );
}

//Homepage Section 1
function HomeBanner() {


    //styling for custom arrows
    const settings = {
        items: 1,
        dots: true,
        autoPlay: true,
        smartSpeed: 2500,
        autoplayTimeout: 500,
        slideTransition: 'linear',
        autoplaySpeed: 3000,
        nextArrow: <SampleNextArrow />,
        prevArrow: <SamplePrevArrow />,
        vertical: false,
        customPaging: (i) => (
            <>
                {changeStyle(i)}
                <div className="ft-slick__dots--custom">
                    {console.log("ii" + i)}
                    <div className="loading" />
                </div>
            </>
        )
    };
    const changeStyle = (i) => {
        console.log("iiiii" + i)

        if (document.getElementById("scroll-thumb"))
            document.getElementById("scroll-thumb").style.left = "100px";

    }
    return (
        <>
            <div className="home_banner">
                <Container fluid>
                    <Row>
                        {/* Section 1 for text */}
                        <Col sm={6} className='slider-image'>

                            <Slider {...settings}>
                                <div>
                                    <img
                                        src={firstimg}
                                        className="w-100 img-fluid"
                                        alt="koovs banner Image"
                                    />
                                </div>
                                <div>
                                    <img
                                        src={firstimg}
                                        className="w-100 img-fluid"
                                        alt="koovs banner Image"
                                    />
                                </div>
                                <div>
                                    <img
                                        src={firstimg}
                                        className="w-100 img-fluid"
                                        alt="koovs banner Image"
                                    />
                                </div>

                            </Slider>

                            <div className="scroll-track" >
                                <div className="scroll-thumb" id="scroll-thumb"></div>
                            </div>
                        </Col>


                        {/* Section 2 for text */}
                        <Col sm={6}>
                            <div className="text d-flex h-100 justify-content-center align-items-center flex-column ">
                                <div className="btn-heading">
                                    Where do you want to start?
                                </div>

                                <div class="d-flex  ">
                                    <div class="row">
                                        <div class="col">
                                            {" "}
                                            <Button className="banner-btn mt-2">Men</Button>
                                        </div>
                                        <div class="col">
                                            {" "}
                                            <Button className="banner-btn mt-2">Women</Button>
                                        </div>
                                        <div class="w-100"></div>

                                        <div class="col">
                                            {" "}
                                            <Button className="banner-btn mt-2">Pre Loved</Button>
                                        </div>
                                        <div class="col">
                                            <Button className="banner-btn mt-2">Collaborations</Button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </Col>
                    </Row>
                    {" "}

                </Container>
            </div>
        </>
    );
}

export default HomeBanner;