import React from 'react';
import { Container, } from 'react-bootstrap'
import './topbrandshome.css'

function topbrandshome() {
    return (
        <div className="topbrands">
            <Container fluid>
                <div className='left-side'>Top brands</div>
                <div className='right-side'><a className='view-all' href="#">View all</a></div>
                <div className="align-text">
                <p className='brand-flex'>361 Degree,AMON,
                </p>
                <p className='brand-flex'>ATTIC SALT, Blue Saint, Bollywoo, DIWAAH, Freakins, Good Stuff, KOOVS, LC Waikiki, New Look, Oxolloxo, ONE/ZERO BY KOOVS, Peak.
                </p>
                
                </div>
                
            </Container>
        </div>
    )
}

export default topbrandshome