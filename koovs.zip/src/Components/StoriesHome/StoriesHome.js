import React from 'react'
import { Container, Col, Row } from 'react-bootstrap';
import './storieshome.css';
import Slider from 'react-slick'
import Carousel from "react-multi-carousel";
import styleimg from '../../assets/images/styleimage.png';

function StoriesHome() {

  //styling for custom arrows
  const settings = {
    items: 3,
    dots: true,
    autoPlay: true,
    smartSpeed: 2500,
    autoplayTimeout: 500,
    slideTransition: 'linear',
    autoplaySpeed: 3000,

  };

  const responsive = {
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 5,

      arrows: false,
      settings: { settings }
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2,
      slidesToSlide: 3
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1,
      slidesToSlide: 2
    }
  };

  return (

    <section className="section-story">

      <div className="style-text">
        <span>Style stories</span>
        <span>Get inspired by our latest campaigns</span>
      </div>

      <div className="row stories">

        {/* Single Product */}
        <Carousel responsive={responsive}
          smartSpeed={2500}
          autoplaySpeed={2000}
          slidesToSlide={1}
          ssr
          showDots={false}
          autoPlay={true}
          infinite
          containerClass="container-with-dots"
          itemClass="image-item"
        >

          {/* Single Product */}
          <div className="classstory">
            <div id="story-1" className="single-story">
              <div className="storypart-1">

                {/* <img src={styleimg}></img> */}

              </div>
            </div>
          </div>


          {/* Single Product */}
          <div className="classstory">
            <div id="story-1" className="single-story">
              <div className="storypart-1">

                {/* <img src={styleimg}></img> */}

              </div>
            </div>
          </div>

          {/* Single Product */}
          <div className="classstory">
            <div id="story-1" className="single-story">
              <div className="storypart-1">

                {/* <img src={styleimg}></img> */}

              </div>
            </div>
          </div>
        </Carousel>
      </div>
    </section>
  )
}

export default StoriesHome
