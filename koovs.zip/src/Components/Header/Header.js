import React,{useState} from 'react';
import "./header.css"
import searchIcon from "../../assets/images/icons/search.png"
import { Container, Col, Row } from 'react-bootstrap';

function Header(){

  const [active,setActive]=useState(false);
    return (
      <header className='header'>

        <div className='navbar'>


          {/* Navigation Bar */}
          <div className='brand-name'>

            {/* menu bar */}
            <div className="icon-menu" onClick={()=>{setActive(!active)}}>
              <svg className={`ham hamRotate ham1 ${active&&"active"}`} viewBox="0 0 100 100" width="80" >
                <path
                  className="line top"
                  d="m 30,33 h 40 c 0,0 9.044436,-0.654587 9.044436,-8.508902 0,-7.854315 -8.024349,-11.958003 -14.89975,-10.85914 -6.875401,1.098863 -13.637059,4.171617 -13.637059,16.368042 v 40" />
                <path
                  className="line middle"
                  d="m 30,50 h 40" />
                <path
                  className="line bottom"
                  d="m 30,67 h 40 c 12.796276,0 15.357889,-11.717785 15.357889,-26.851538 0,-15.133752 -4.786586,-27.274118 -16.667516,-27.274118 -11.88093,0 -18.499247,6.994427 -18.435284,17.125656 l 0.252538,40" />
              </svg>
            </div>

            {/* Hamburger menu */}
            <div className={`navbar-collapse main-nav ${active&&"active"}`} id="navbarSupportedContent20">
              <Container fluid>
                <Row>
                  <Col sm={2}>
                    <ul class="navbar-nav mr-auto">
                      <li class="nav-item active">
                        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#">Features</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#">Pricing</a>
                      </li>
                    </ul>
                  </Col>
                  <Col sm={2}>
                    <ul class="navbar-nav mr-auto">
                      <li class="nav-item active">
                        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#">Features</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#">Pricing</a>
                      </li>
                    </ul>
                  </Col>
                  <Col sm={2}>
                    <ul class="navbar-nav mr-auto">
                      <li class="nav-item active">
                        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#">Features</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#">Pricing</a>
                      </li>
                    </ul>
                  </Col>
                  <Col sm={2}>
                    <ul class="navbar-nav mr-auto">
                      <li class="nav-item active">
                        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#">Features</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#">Pricing</a>
                      </li>
                    </ul>
                  </Col>
                  <Col sm={2}>
                    <ul class="navbar-nav mr-auto">
                      <li class="nav-item active">
                        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#">Features</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#">Pricing</a>
                      </li>
                    </ul>
                  </Col>
                </Row>



              </Container>
            </div>





















          </div>
          <div className='koovsHeading'>
            <h3>Koovs</h3>
          </div>
          <div class="d-flex flex-row">

            <span className='px-4'>
              <img src={searchIcon} />
            </span>
            <span className='px-4'>
              <h4>Account</h4>
            </span>
            <span className='px-4'>
              <h4>Cart (0)</h4>
            </span>

          </div>
        </div>


      </header>
    )

}
export default Header;

